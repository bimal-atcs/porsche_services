//run when page first loads
$(document).ready(function () {
});

//run on every window resize
$(window).resize(function () {
});