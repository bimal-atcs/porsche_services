$(".next-card-slider").slick({
    dots: false,
    autoplay: true,
    autoplaySpeed: 3000,
    arrows: false,
    slidesToShow: 1,
    slidesToScroll: 1,
    speed: 1000,
    fade: true,
    draggable: true
});